package com.pricing.engine;

import com.pricing.factory.OfferFactory;
import com.pricing.model.Cart;
import com.pricing.model.CartEvaluationResult;
import com.pricing.model.CartItem;
import com.pricing.model.LineItemResult;
import com.pricing.model.Product;
import com.pricing.repository.CartRepository;
import com.pricing.repository.OfferRepository;
import com.pricing.repository.ProductRepository;
import com.pricing.strategy.BestSingleOfferStrategy;
import com.pricing.strategy.OfferSelectionStrategy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PricingEngine {

    private final ProductRepository productRepository = new ProductRepository();
    private final OfferRepository offerRepository     = new OfferRepository();
    private final CartRepository cartRepository       = new CartRepository();
    private final OfferFactory offerFactory           = new OfferFactory();
    private final OfferSelectionStrategy strategy     = new BestSingleOfferStrategy();

    public void addProduct(String name, double basePrice) {

        productRepository.save(new Product(name.toLowerCase(), name, basePrice));
    }

    public void createPercentageOffer(String offerId, List<String> productNames,
                                      double discountPercentage, int minQty, int maxGlobalUses) {

        offerRepository.save(offerFactory.createPercentageOffer(
                offerId, resolveIds(productNames), discountPercentage, minQty, maxGlobalUses));
    }

    public void createFlatOffer(String offerId, List<String> productNames,
                                double flatAmount, int minQty, int maxGlobalUses) {

        offerRepository.save(offerFactory.createFlatOffer(
                offerId, resolveIds(productNames), flatAmount, minQty, maxGlobalUses));
    }

    public void createCart(String cartId) {
        cartRepository.save( new Cart(cartId));
    }

    public void addToCart(String cartId, String productName, int quantity) {
        Cart cart = cartRepository.findById(cartId);
        if (cart == null) throw new IllegalArgumentException("Cart not found: " + cartId);

        Product product = productRepository.findById(productName.toLowerCase());

        if (product == null) throw new IllegalArgumentException("Product not found: " + productName);

        cart.addItem(product, quantity);
    }

    public CartEvaluationResult evaluateCart(String cartId) {
        Cart cart = cartRepository.findById(cartId);
        if (cart == null) throw new IllegalArgumentException("Cart not found: " + cartId);

        List<LineItemResult> lineItems = new ArrayList<>();
        for (CartItem item : cart.getItems()) {
            lineItems.add(strategy.evaluate(item, offerRepository.findByProductId(item.getProduct().getId())));
        }
        return new CartEvaluationResult(lineItems);
    }

    private Set<String> resolveIds(List<String> names) {
        Set<String> ids = new HashSet<>();
        for (String name : names) {
            String id = name.toLowerCase();
            if (!productRepository.exists(id))
                throw new IllegalArgumentException("Product not found: " + name);
            ids.add(id);
        }

        return ids;
    }
}
