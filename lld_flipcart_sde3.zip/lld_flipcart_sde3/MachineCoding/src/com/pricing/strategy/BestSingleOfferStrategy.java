package com.pricing.strategy;

import com.pricing.model.CartItem;
import com.pricing.model.LineItemResult;
import com.pricing.model.Offer;
import com.pricing.model.Product;

import java.util.ArrayList;
import java.util.List;

public class BestSingleOfferStrategy implements OfferSelectionStrategy {

    @Override
    public LineItemResult evaluate(CartItem item, List<Offer> candidateOffers) {
        Product product = item.getProduct();
        double basePrice = product.getBasePrice();
        int qty = item.getQuantity();

        List<String> validOfferIds = new ArrayList<>();
        Offer bestOffer = null;
        double bestDiscount = 0;

        for (Offer offer : candidateOffers) {
            if (!offer.isApplicable(product.getId(), qty) || !offer.hasCapacity()) continue;
            validOfferIds.add(offer.getOfferId());
            double discount = offer.calculateDiscountPerUnit(basePrice);
            if (discount > bestDiscount && basePrice - discount > 0) {
                bestDiscount = discount;
                bestOffer = offer;
            }
        }

        if (bestOffer != null && bestOffer.tryRedeem()) {
            return new LineItemResult(product.getName(), qty, basePrice,
                    validOfferIds, bestOffer.getOfferId(), bestDiscount * qty);
        }

        return new LineItemResult(product.getName(), qty, basePrice, validOfferIds, null, 0.0);
    }
}
