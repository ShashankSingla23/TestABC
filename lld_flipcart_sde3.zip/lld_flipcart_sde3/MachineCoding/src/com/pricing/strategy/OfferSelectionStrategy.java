package com.pricing.strategy;

import com.pricing.model.CartItem;
import com.pricing.model.LineItemResult;
import com.pricing.model.Offer;

import java.util.List;

public interface OfferSelectionStrategy {

    LineItemResult evaluate(CartItem item, List<Offer> candidateOffers);
}
