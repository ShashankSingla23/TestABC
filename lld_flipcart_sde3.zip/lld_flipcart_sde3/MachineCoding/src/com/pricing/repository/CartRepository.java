package com.pricing.repository;

import com.pricing.model.Cart;

import java.util.HashMap;
import java.util.Map;

public class CartRepository {

    private final Map<String, Cart> store = new HashMap<>();

    public void save(Cart cart) {
        if (store.containsKey(cart.getCartId())) {
            throw new IllegalStateException("Cart already exists: " + cart.getCartId());
        }

        store.put(cart.getCartId(), cart);
    }

    public Cart findById(String id) {
        return store.get(id);
    }
}
