package com.pricing.repository;

import com.pricing.model.Product;

import java.util.HashMap;
import java.util.Map;

public class ProductRepository {

    private final Map<String, Product> store = new HashMap<>();

    public void save(Product product) {
        if (store.containsKey(product.getId())) {
            throw new IllegalStateException("Product already exists: " + product.getId());
        }

        store.put(product.getId(), product);
    }

    public Product findById(String id) {
        return store.get(id);
    }

    public boolean exists(String id) {
        return store.containsKey(id);
    }
}
