package com.pricing.repository;

import com.pricing.model.Offer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OfferRepository {

    private final Map<String, Offer> offers = new HashMap<>();
    private final Map<String, List<Offer>> productOfferIndex = new HashMap<>();

    public void save(Offer offer) {
        if (offers.containsKey(offer.getOfferId())) {
            throw new IllegalStateException("Offer already exists: " + offer.getOfferId());
        }

        offers.put(offer.getOfferId(), offer);
        for (String productId : offer.getProductIds()) {
            productOfferIndex.computeIfAbsent(productId, k -> new ArrayList<>()).add(offer);
        }
    }

    public List<Offer> findByProductId(String productId) {
        List<Offer> result = productOfferIndex.get(productId);
        return result != null ? result : Collections.emptyList();
    }
}
