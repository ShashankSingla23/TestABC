package com.pricing.model;

import java.util.HashSet;
import java.util.Set;

public abstract class Offer {

    private final String offerId;
    private final Set<String> productIds;
    private final int minQty;
    private final int maxGlobalUses;
    private int currentUseCount = 0;

    protected Offer(String offerId, Set<String> productIds, int minQty, int maxGlobalUses) {
        if (offerId == null) throw new IllegalArgumentException("Offer id must not be blank");
        if (productIds == null || productIds.isEmpty()) throw new IllegalArgumentException("Offer must target at least one product");
        if (minQty < 1) throw new IllegalArgumentException("minQty must be >= 1");
        this.offerId = offerId;
        this.productIds = new HashSet<>(productIds);
        this.minQty = minQty;
        this.maxGlobalUses = maxGlobalUses;
    }

    public abstract double calculateDiscountPerUnit(double basePrice);

    public boolean isApplicable(String productId, int qty) {
        return productIds.contains(productId) && qty >= minQty;
    }

    public boolean hasCapacity() {
        return currentUseCount < maxGlobalUses;
    }

    // for cuncurrent request handling
    public synchronized boolean tryRedeem() {
        if (currentUseCount >= maxGlobalUses) return false;
        currentUseCount++;
        return true;
    }

    public String getOfferId()         { return offerId; }
    public Set<String> getProductIds() { return productIds; }
}
