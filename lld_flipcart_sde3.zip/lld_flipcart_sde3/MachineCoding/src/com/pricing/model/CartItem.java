package com.pricing.model;

public class CartItem {

    private final Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        if (product == null) throw new IllegalArgumentException("Product must not be null");
        if (quantity < 1) throw new IllegalArgumentException("Quantity must be >= 1");

        this.product = product;
        this.quantity = quantity;
    }

    public void addQuantity(int extra) {
        if (extra < 1) throw new IllegalArgumentException("Extra quantity must be >= 1");
        this.quantity += extra;
    }

    public Product getProduct() {
        return product;
    }
    public int getQuantity() {
        return quantity;
    }
}
