package com.pricing.model;

import java.util.Set;

public class PercentageDiscountOffer extends Offer {

    private final double discountPercentage;

    public PercentageDiscountOffer(String offerId, Set<String> productIds,
                                   double discountPercentage, int minQty, int maxGlobalUses) {
        super(offerId, productIds, minQty, maxGlobalUses);
        if (discountPercentage <= 0 || discountPercentage >= 100)
            throw new IllegalArgumentException("Discount percentage must be in (0, 100)");

        this.discountPercentage = discountPercentage;
    }

    @Override
    public double calculateDiscountPerUnit(double basePrice) {
        return basePrice * discountPercentage / 100.0;
    }

}
