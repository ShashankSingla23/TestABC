package com.pricing.model;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class Cart {

    private final String cartId;
    private final Map<String, CartItem> items = new LinkedHashMap<>();

    public Cart(String cartId) {
        if (cartId == null) throw new IllegalArgumentException("Cart id must not be blank");
        this.cartId = cartId;
    }

    public void addItem(Product product, int quantity) {
        if (product == null) throw new IllegalArgumentException("Product must not be null");
        if (quantity < 1) throw new IllegalArgumentException("Quantity must be >= 1");
        if (items.containsKey(product.getId())) {
            items.get(product.getId()).addQuantity(quantity);
        } else {
            items.put(product.getId(), new CartItem(product, quantity));
        }
    }

    public Collection<CartItem> getItems() {
        return items.values();
    }

    public String getCartId() { return cartId; }
}
