package com.pricing.model;

import java.util.List;

public class LineItemResult {

    private final String productName;
    private final int quantity;
    private final double totalBasePrice;
    private final List<String> validOfferIds;
    private final String appliedOfferId;
    private final double totalDiscount;
    private final double finalPrice;

    public LineItemResult(String productName, int quantity, double unitBasePrice,
                          List<String> validOfferIds, String appliedOfferId, double totalDiscount) {
        this.productName = productName;
        this.quantity = quantity;
        this.totalBasePrice = unitBasePrice * quantity;
        this.validOfferIds = validOfferIds;
        this.appliedOfferId = appliedOfferId;
        this.totalDiscount = totalDiscount;
        this.finalPrice = this.totalBasePrice - totalDiscount;
    }

    public double getTotalBasePrice() { return totalBasePrice; }
    public double getTotalDiscount()  { return totalDiscount; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(productName)
          .append(": Qty ").append(quantity)
          .append(". Base = ").append((int) totalBasePrice)
          .append(". Valid Offers: ");

        if (validOfferIds.isEmpty()) {
            sb.append("None");
        } else {
            sb.append(String.join(", ", validOfferIds));
        }

        if (appliedOfferId != null) {
            sb.append(". Best Offer Applied: ").append(appliedOfferId);
        }

        sb.append(". Discount = ").append((int) totalDiscount)
          .append(". Final = ").append((int) finalPrice)
          .append(".");
        return sb.toString();
    }
}
