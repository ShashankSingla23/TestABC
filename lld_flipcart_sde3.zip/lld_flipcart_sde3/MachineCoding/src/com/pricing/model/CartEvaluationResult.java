package com.pricing.model;

import java.util.List;

public class CartEvaluationResult {

    private final List<LineItemResult> lineItems;
    private double totalBasePrice;
    private double totalDiscount;
    private double finalAmount;

    public CartEvaluationResult(List<LineItemResult> lineItems) {
        this.lineItems = lineItems;
        for (LineItemResult item : lineItems) {
            totalBasePrice += item.getTotalBasePrice();
            totalDiscount  += item.getTotalDiscount();
        }
        finalAmount = totalBasePrice - totalDiscount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (LineItemResult item : lineItems) {
            sb.append(item).append("\n");
        }
        sb.append("Cart Total: Base = ").append((int) totalBasePrice)
          .append(". Total Discount = ").append((int) totalDiscount)
          .append(". Final Amount To Pay = ").append((int) finalAmount)
          .append(".");
        return sb.toString();
    }
}
