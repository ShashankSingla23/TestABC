package com.pricing.model;

import java.util.Set;

public class FlatDiscountOffer extends Offer {

    private final double flatDiscountAmount;

    public FlatDiscountOffer(String offerId, Set<String> productIds,
                             double flatDiscountAmount, int minQty, int maxGlobalUses) {
        super(offerId, productIds, minQty, maxGlobalUses);
        if (flatDiscountAmount <= 0) throw new IllegalArgumentException("Flat discount must be positive");

        this.flatDiscountAmount = flatDiscountAmount;
    }

    @Override
    public double calculateDiscountPerUnit(double basePrice) {

        return Math.min(flatDiscountAmount, basePrice);
    }

}
