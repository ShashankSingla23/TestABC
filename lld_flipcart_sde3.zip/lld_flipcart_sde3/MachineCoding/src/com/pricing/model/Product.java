package com.pricing.model;

public class Product {

    private final String id;
    private final String name;
    private final double basePrice;

    public Product(String id, String name, double basePrice) {
        if (id == null) throw new IllegalArgumentException("Product id must not be blank");
        if (name == null) throw new IllegalArgumentException("Product name must not be blank");
        if (basePrice <= 0) throw new IllegalArgumentException("Base price must be positive");
        this.id = id;
        this.name = name;
        this.basePrice = basePrice;
    }

    public String getId()        { return id; }

    public String getName()      { return name; }

    public double getBasePrice() { return basePrice; }
}
