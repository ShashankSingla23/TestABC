package com.pricing.factory;

import com.pricing.model.FlatDiscountOffer;
import com.pricing.model.Offer;
import com.pricing.model.PercentageDiscountOffer;

import java.util.Set;

public class OfferFactory {

    public Offer createPercentageOffer(String offerId, Set<String> productIds,
                                       double discountPercentage, int minQty, int maxGlobalUses) {
        return new PercentageDiscountOffer(offerId, productIds, discountPercentage, minQty, maxGlobalUses);
    }

    public Offer createFlatOffer(String offerId, Set<String> productIds,
                                 double flatDiscountAmount, int minQty, int maxGlobalUses) {
        return new FlatDiscountOffer(offerId, productIds, flatDiscountAmount, minQty, maxGlobalUses);
    }
}
