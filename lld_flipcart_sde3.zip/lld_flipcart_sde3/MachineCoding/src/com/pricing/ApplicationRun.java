package com.pricing;

import com.pricing.engine.PricingEngine;

import java.util.Arrays;
import java.util.List;

public class ApplicationRun {

    public static void main(String[] args) {
        PricingEngine engine = new PricingEngine();
        engine.addProduct("Shirt", 1000);
        engine.addProduct("Shoes", 2000);
        engine.addProduct("Socks", 500);

        engine.createPercentageOffer("OFFER1", list("Shirt", "Socks"), 10, 2, 2);
        engine.createFlatOffer("OFFER2", list("Shoes"), 300, 1, 5);
        engine.createPercentageOffer("OFFER3", list("Shoes"), 20, 2, 1);


        engine.createCart("Cart1");
        engine.addToCart("Cart1", "Shirt", 2);
        engine.addToCart("Cart1", "Shoes", 2);
        System.out.println(engine.evaluateCart("Cart1"));
        System.out.println("--------------------------------");

        engine.createCart("Cart2");
        engine.addToCart("Cart2", "Shirt", 2);
        engine.addToCart("Cart2", "Shoes", 2);
        System.out.println(engine.evaluateCart("Cart2"));
        System.out.println("--------------------------------");

        engine.createCart("Cart3");
        engine.addToCart("Cart3", "Socks", 3);
        System.out.println(engine.evaluateCart("Cart3"));
        System.out.println("--------------------------------");


        //more test cases

//        engine.createCart("Cart4");
//        engine.addToCart("Cart4", "Shirt", 1);
//        System.out.println(engine.evaluateCart("Cart4"));
//
//        engine.createCart("Cart5");
//        engine.addToCart("Cart5", "Shirt", 2);
//        engine.addToCart("Cart5", "Socks", 3);
//        engine.addToCart("Cart5", "Shoes", 1);
//        System.out.println(engine.evaluateCart("Cart5"));
//
//        engine.createCart("Cart6");
//        engine.addToCart("Cart6", "Shoes", 1);
//        System.out.println(engine.evaluateCart("Cart6"));

    }

    private static List<String> list(String... names) {

        return Arrays.asList(names);
    }
}
